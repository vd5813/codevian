import React from 'react';
import logo from './logo.svg';
import './App.css';
import { Link, Route, Switch } from 'react-router-dom'
import Login from './components/Login'
import Logout from './components/Logout'
import User from './components/User'

function App() {
  return (
    <Switch>
      <Route exact path="/" component={Login} />
      <Route exact path="/logout" component={Logout} />
      <Route exact path="/user" component={User} />
    </Switch>
  );
}

const A = () => {
  return (
    <div>
      <h1>This is component A page</h1>
      <Link to="/b"> B Component </Link>
    </div>
  )
}

const B = () => {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  )
}


export default App;
