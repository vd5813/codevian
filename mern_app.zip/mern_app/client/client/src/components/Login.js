import React, { Component } from 'react'

export default class Login extends Component {

    constructor(props) {
        super(props)
        let loggedIn = false
        this.state = {
            email: '',
            password: '',
            loggedIn
        }
        this.onChange = this.onChange.bind(this)
        this.submitForm = this.submitForm.bind(this)
    }

    onChange(e) {
        this.setState({
            [e.target.email]: e.target.value
        })
    }

    submitForm(e) {
        e.preventDefault()
        const { email, password } = this.state
    }

    render() {
        return (
            <div>
                <h1>Login</h1>
                <form onSubmit={this.submitForm}>
                    <input type="text" placeholder="email" name="email" value={this.state.email} onChange={this.onChange} />
                    <br />
                    <input type="text" placeholder="password" name="password" value={this.state.password} onChange={this.onChange} />
                    <br />
                    <input type="submit" />
                    <br />
                </form>
            </div>
        )
    }
}


